from idlsave import read

__version__ = '0.9.5'
